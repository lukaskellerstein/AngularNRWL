import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { Department } from '../entitites/department.model';

@Injectable()
export class DepartmentService {
  constructor(private http: HttpClient) {}

  getAllDepartments(): Observable<Array<Department>> {
    let newItem1 = <Department>{
      name: 'Electro',
      image: 'none'
    };

    let newItem2 = <Department>{
      name: 'Hobby',
      image: 'none'
    };

    let newItem3 = <Department>{
      name: 'Sport',
      image: 'none'
    };

    let result = new Array<Department>();
    result.push(newItem1);
    result.push(newItem2);
    result.push(newItem3);

    return of(result);
  }
}
