
/** Department Resource - V1 */
export interface Department {
    name: string;
    image?: string;
  }