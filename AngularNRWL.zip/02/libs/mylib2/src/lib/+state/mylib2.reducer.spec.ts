import { Mylib2Loaded } from './mylib2.actions';
import { mylib2Reducer, initialState } from './mylib2.reducer';

describe('mylib2Reducer', () => {
  it('should work', () => {
    const action: Mylib2Loaded = new Mylib2Loaded({});
    const actual = mylib2Reducer(initialState, action);
    expect(actual).toEqual({});
  });
});
