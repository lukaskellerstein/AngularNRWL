import { TestBed } from '@angular/core/testing';
import { StoreModule } from '@ngrx/store';
import { provideMockActions } from '@ngrx/effects/testing';
import { DataPersistence } from '@nrwl/nx';
import { hot } from '@nrwl/nx/testing';

import { Mylib1Effects } from './mylib1.effects';
import { LoadMylib1, Mylib1Loaded } from './mylib1.actions';

import { Observable } from 'rxjs';

describe('Mylib1Effects', () => {
  let actions$: Observable<any>;
  let effects$: Mylib1Effects;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [StoreModule.forRoot({})],
      providers: [
        Mylib1Effects,
        DataPersistence,
        provideMockActions(() => actions$)
      ]
    });

    effects$ = TestBed.get(Mylib1Effects);
  });

  describe('someEffect', () => {
    it('should work', () => {
      actions$ = hot('-a-|', { a: new LoadMylib1({}) });
      expect(effects$.loadMylib1$).toBeObservable(
        hot('-a-|', { a: new Mylib1Loaded({}) })
      );
    });
  });
});
