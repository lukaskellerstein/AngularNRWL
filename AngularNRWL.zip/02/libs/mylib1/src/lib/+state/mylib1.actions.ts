import { Action } from '@ngrx/store';
import { Employee } from '../entities/employee.model';

export enum Mylib1ActionTypes {
  Mylib1Action = '[Mylib1] Action',
  LoadMylib1 = '[Mylib1] Load Data',
  Mylib1Loaded = '[Mylib1] Data Loaded'
}

export class Mylib1 implements Action {
  readonly type = Mylib1ActionTypes.Mylib1Action;
}
export class LoadMylib1 implements Action {
  readonly type = Mylib1ActionTypes.LoadMylib1;
  constructor(public payload: any) {}
}

export class Mylib1Loaded implements Action {
  readonly type = Mylib1ActionTypes.Mylib1Loaded;
  constructor(public payload: any) {}
}

/*************************************************************/
/*  CUSTOM   */
/*************************************************************/

export const LOAD_EMPLOYEES_LIST = '[Mylib1] Load Employees List';
export const LOAD_EMPLOYEES_LIST_ERROR = '[Mylib1] Load Employees List Error';
export const LOAD_EMPLOYEES_LIST_SUCCESS =
  '[Mylib1] Load Employees List Success';

export class LoadEmployeesList implements Action {
  readonly type = LOAD_EMPLOYEES_LIST;
}

export class LoadEmployeesListSuccess implements Action {
  readonly type = LOAD_EMPLOYEES_LIST_SUCCESS;

  constructor(public payload: Employee[]) {}
}

export class LoadEmployeesListError implements Action {
  readonly type = LOAD_EMPLOYEES_LIST_ERROR;

  constructor(public payload: string) {}
}

export type Mylib1Actions =
  | Mylib1
  | LoadMylib1
  | Mylib1Loaded
  | LoadEmployeesList
  | LoadEmployeesListError
  | LoadEmployeesListSuccess;
