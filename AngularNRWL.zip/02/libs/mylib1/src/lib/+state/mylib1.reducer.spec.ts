import { Mylib1Loaded } from './mylib1.actions';
import { mylib1Reducer, initialState } from './mylib1.reducer';

describe('mylib1Reducer', () => {
  it('should work', () => {
    const action: Mylib1Loaded = new Mylib1Loaded({});
    const actual = mylib1Reducer(initialState, action);
    expect(actual).toEqual({});
  });
});
