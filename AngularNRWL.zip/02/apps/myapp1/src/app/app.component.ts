import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { AppState } from './+state/app.reducer';
import { Observable } from 'rxjs';
import { Language } from './entities/language.model';
import { LanguageChange, LoadLanguages } from './+state/app.actions';
import { Department } from 'libs/mylib2/src/lib/entitites/department.model';
import { Mylib1State } from 'libs/mylib1/src/lib/+state/mylib1.reducer';
import { Mylib2State } from 'libs/mylib2/src/lib/+state/mylib2.reducer';
import { Employee } from 'libs/mylib1/src/lib/entities/employee.model';
import { LoadEmployeesList } from 'libs/mylib1/src/lib/+state/mylib1.actions';
import { LoadDepartmentList } from 'libs/mylib2/src/lib/+state/mylib2.actions';

@Component({
  selector: 'TestSolution2-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'TestSolution2';

  
  constructor(private storeApp: Store<AppState>,
    private storeLib1: Store<Mylib1State>,
    private storeLib2: Store<Mylib2State>) {}


  languages$: Observable<Language[]> = this.storeApp.select(
    state => state.app.languageState.languages
  );

  employees$: Observable<Employee[]> = this.storeLib1.select(
    state => state.mylib1.employeesList.employees
  );

  departments$: Observable<Department[]> = this.storeLib2.select(
    state => state.mylib2.departmentList.departments
  );

  ngOnInit(): void {
    this.storeApp.dispatch(new LoadLanguages());
  }

  chooseLang(lang: string) {
    this.storeApp.dispatch(new LanguageChange(lang));
  }

  loadEmployees(){
    this.storeLib1.dispatch(new LoadEmployeesList());
  }

  loadDepartments(){
    this.storeLib2.dispatch(new LoadDepartmentList());
  }
}
