import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Language } from '../entities/language.model';
import { of } from 'rxjs/observable/of';

@Injectable()
export class LanguageService {
  constructor(private http: HttpClient) {}

  getAllLanguages(): Observable<Array<Language>> {
    let newLang1 = <Language>{
      code: 'CZ',
      name: 'Czech'
    };

    let newLang2 = <Language>{
      code: 'DE',
      name: 'Deutsch'
    };

    let newLang3 = <Language>{
      code: 'EN',
      name: 'English'
    };

    let result = new Array<Language>();
    result.push(newLang1);
    result.push(newLang2);
    result.push(newLang3);

    return of(result);
  }
}
