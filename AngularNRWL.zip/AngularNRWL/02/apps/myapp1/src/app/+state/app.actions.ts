import { Action } from '@ngrx/store';

export enum AppActionTypes {
  AppAction = '[App] Action',
  LoadApp = '[App] Load Data',
  AppLoaded = '[App] Data Loaded'
}

export class App implements Action {
  readonly type = AppActionTypes.AppAction;
}
export class LoadApp implements Action {
  readonly type = AppActionTypes.LoadApp;
  constructor(public payload: any) {}
}

export class AppLoaded implements Action {
  readonly type = AppActionTypes.AppLoaded;
  constructor(public payload: any) {}
}

/*************************************************************/
/*  CUSTOM   */
/*************************************************************/

export const LANGUAGE_CHANGE = '[Language] change';
export const LOAD_LANGUAGES = '[Language] load languages';
export const LOAD_LANGUAGES_SUCCESS = '[Language] load languages success';
export const LOAD_LANGUAGES_ERROR = '[Language] load languages error';

export class LanguageChange implements Action {
  readonly type = LANGUAGE_CHANGE;

  constructor(public payload: string) {}
}

export class LoadLanguages implements Action {
  readonly type = LOAD_LANGUAGES;
  constructor() {}
}

export class LoadLanguagesSuccess implements Action {
  readonly type = LOAD_LANGUAGES_SUCCESS;

  constructor(public payload: any) {}
}

export class LoadLanguagesError implements Action {
  readonly type = LOAD_LANGUAGES_ERROR;

  constructor(public payload: string) {}
}

export type AppActions =
  | App
  | LoadApp
  | AppLoaded
  | LanguageChange
  | LoadLanguages
  | LoadLanguagesSuccess
  | LoadLanguagesError;
