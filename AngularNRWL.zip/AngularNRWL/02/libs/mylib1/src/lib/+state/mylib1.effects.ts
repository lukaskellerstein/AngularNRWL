import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import {
  Mylib1Actions,
  Mylib1ActionTypes,
  LoadMylib1,
  Mylib1Loaded
} from './mylib1.actions';
import { Mylib1State } from './mylib1.reducer';
import { DataPersistence } from '@nrwl/nx';

// ngRX actions
import {
  LOAD_EMPLOYEES_LIST,
  LoadEmployeesList,
  LoadEmployeesListError,
  LoadEmployeesListSuccess
} from './mylib1.actions';
import { EmployeeService } from '../services/employees.service';
import { switchMap, map, catchError } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';

@Injectable()
export class Mylib1Effects {
  @Effect() effect$ = this.actions$.ofType(Mylib1ActionTypes.Mylib1Action);

  @Effect()
  loadMylib1$ = this.dataPersistence.fetch(Mylib1ActionTypes.LoadMylib1, {
    run: (action: LoadMylib1, state: Mylib1State) => {
      return new Mylib1Loaded(state);
    },

    onError: (action: LoadMylib1, error) => {
      console.error('Error', error);
    }
  });

  constructor(
    private actions$: Actions,
    private dataPersistence: DataPersistence<Mylib1State>,
    private employeeService: EmployeeService
  ) {}

  /*************************************************************/
  /*  CUSTOM   */
  /*************************************************************/

  /* Employees list page*/
  @Effect()
  loadEmployeesList = this.actions$.pipe(
    ofType<LoadEmployeesList>(LOAD_EMPLOYEES_LIST),
    switchMap((action: LoadEmployeesList) => {
      return this.employeeService
        .getAllEmployees()
        .pipe(
          map(employees => new LoadEmployeesListSuccess(employees)),
          catchError((error: Error) =>
            of(new LoadEmployeesListError(error.message))
          )
        );
    })
  );
}
