import { Action } from '@ngrx/store';
import {
  Mylib1Actions,
  Mylib1ActionTypes,
  LOAD_EMPLOYEES_LIST,
  LOAD_EMPLOYEES_LIST_SUCCESS,
  LOAD_EMPLOYEES_LIST_ERROR
} from './mylib1.actions';
import { Employee } from '../entities/employee.model';

// Abstraction
export interface LoadingAndErrorState {
  loading?: boolean;
  error?: string;
}

// Employees -----------------------------
export interface EmployeesListState extends LoadingAndErrorState {
  employees: Employee[];
}

export const initialEmployeesListState: EmployeesListState = {
  employees: [],
  loading: false,
  error: null
};

/**
 * Interface for the 'Mylib1' data used in
 *  - Mylib1State, and
 *  - mylib1Reducer
 */
export interface Mylib1Data {
  employeesList: EmployeesListState;
}

/**
 * Interface to the part of the Store containing Mylib1State
 * and other information related to Mylib1Data.
 */
export interface Mylib1State {
  readonly mylib1: Mylib1Data;
}

export const initialState: Mylib1Data = {
  employeesList: initialEmployeesListState
};

export function mylib1Reducer(
  state = initialState,
  action: Mylib1Actions
): Mylib1Data {
  switch (action.type) {
    case Mylib1ActionTypes.Mylib1Action:
      return state;

    case Mylib1ActionTypes.Mylib1Loaded: {
      return { ...state, ...action.payload };
    }

    case LOAD_EMPLOYEES_LIST_SUCCESS:
      return {
        ...state,
        employeesList: {
          employees: action.payload,
          loading: true,
          error: null
        }
      };

    case LOAD_EMPLOYEES_LIST_ERROR:
      return {
        ...state,
        employeesList: {
          ...state.employeesList,
          loading: false,
          error: action.payload
        }
      };

    default:
      return state;
  }
}
