import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import {
  mylib1Reducer,
  initialState as mylib1InitialState
} from './+state/mylib1.reducer';
import { Mylib1Effects } from './+state/mylib1.effects';
import { EmployeeService } from './services/employees.service';
@NgModule({
  imports: [
    CommonModule,
    StoreModule.forFeature('mylib1', mylib1Reducer, {
      initialState: mylib1InitialState
    }),
    EffectsModule.forFeature([Mylib1Effects])
  ],
  providers: [Mylib1Effects, EmployeeService]
})
export class Mylib1Module {}
