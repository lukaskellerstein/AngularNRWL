import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import {
  mylib2Reducer,
  initialState as mylib2InitialState
} from './+state/mylib2.reducer';
import { Mylib2Effects } from './+state/mylib2.effects';
import { DepartmentService } from './services/department.service';
@NgModule({
  imports: [
    CommonModule,
    StoreModule.forFeature('mylib2', mylib2Reducer, {
      initialState: mylib2InitialState
    }),
    EffectsModule.forFeature([Mylib2Effects])
  ],
  providers: [Mylib2Effects, DepartmentService]
})
export class Mylib2Module {}
