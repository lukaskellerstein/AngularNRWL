import { Action } from '@ngrx/store';
import { Mylib2Actions, Mylib2ActionTypes, LOAD_DEPARTMENT_LIST_SUCCESS, LOAD_DEPARTMENT_LIST_ERROR } from './mylib2.actions';
import { Department } from '../entitites/department.model';


// Abstraction
export interface LoadingAndErrorState {
  loading?: boolean;
  error?: string;
}

// Departments -----------------------------
export interface DepartmentListState extends LoadingAndErrorState {
  departments: Department[];
}

export const initialDepartmentListState: DepartmentListState = {
  departments: [],
  loading: false,
  error: null
};



/**
 * Interface for the 'Mylib2' data used in
 *  - Mylib2State, and
 *  - mylib2Reducer
 */
export interface Mylib2Data {
  departmentList: DepartmentListState
}

/**
 * Interface to the part of the Store containing Mylib2State
 * and other information related to Mylib2Data.
 */
export interface Mylib2State {
  readonly mylib2: Mylib2Data;
}

export const initialState: Mylib2Data = {
  departmentList: initialDepartmentListState,
};

export function mylib2Reducer(
  state = initialState,
  action: Mylib2Actions
): Mylib2Data {
  switch (action.type) {
    case Mylib2ActionTypes.Mylib2Action:
      return state;

    case Mylib2ActionTypes.Mylib2Loaded: {
      return { ...state, ...action.payload };
    }

    case LOAD_DEPARTMENT_LIST_SUCCESS:
      return {
        ...state, 
        departmentList: {
          ...state.departmentList,
          departments: action.payload,
          loading: true,
          error: null
        }
      };

    case LOAD_DEPARTMENT_LIST_ERROR:
      return {
        ...state, 
        departmentList: {
          departments: [],
          loading: false,
          error: action.payload
        }
      };

    default:
      return state;
  }
}
