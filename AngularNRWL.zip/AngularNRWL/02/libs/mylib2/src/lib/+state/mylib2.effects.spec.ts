import { TestBed } from '@angular/core/testing';
import { StoreModule } from '@ngrx/store';
import { provideMockActions } from '@ngrx/effects/testing';
import { DataPersistence } from '@nrwl/nx';
import { hot } from '@nrwl/nx/testing';

import { Mylib2Effects } from './mylib2.effects';
import { LoadMylib2, Mylib2Loaded } from './mylib2.actions';

import { Observable } from 'rxjs';

describe('Mylib2Effects', () => {
  let actions$: Observable<any>;
  let effects$: Mylib2Effects;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [StoreModule.forRoot({})],
      providers: [
        Mylib2Effects,
        DataPersistence,
        provideMockActions(() => actions$)
      ]
    });

    effects$ = TestBed.get(Mylib2Effects);
  });

  describe('someEffect', () => {
    it('should work', () => {
      actions$ = hot('-a-|', { a: new LoadMylib2({}) });
      expect(effects$.loadMylib2$).toBeObservable(
        hot('-a-|', { a: new Mylib2Loaded({}) })
      );
    });
  });
});
