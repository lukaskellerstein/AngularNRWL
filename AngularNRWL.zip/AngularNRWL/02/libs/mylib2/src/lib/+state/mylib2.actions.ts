import { Action } from '@ngrx/store';
import { Department } from '../entitites/department.model';

export enum Mylib2ActionTypes {
  Mylib2Action = '[Mylib2] Action',
  LoadMylib2 = '[Mylib2] Load Data',
  Mylib2Loaded = '[Mylib2] Data Loaded'
}

export class Mylib2 implements Action {
  readonly type = Mylib2ActionTypes.Mylib2Action;
}
export class LoadMylib2 implements Action {
  readonly type = Mylib2ActionTypes.LoadMylib2;
  constructor(public payload: any) {}
}

export class Mylib2Loaded implements Action {
  readonly type = Mylib2ActionTypes.Mylib2Loaded;
  constructor(public payload: any) {}
}


/*************************************************************/
/*  CUSTOM   */
/*************************************************************/


export const LOAD_DEPARTMENT_LIST = '[Career Landing Page] Load Department List';
export const LOAD_DEPARTMENT_LIST_ERROR = '[Career Landing Page] Load Department List Error';
export const LOAD_DEPARTMENT_LIST_SUCCESS = '[Career Landing Page] Load Department List Success';

export class LoadDepartmentList implements Action {
  readonly type = LOAD_DEPARTMENT_LIST;

  constructor() {
  }
}

export class LoadDepartmentListSuccess implements Action {
  readonly type = LOAD_DEPARTMENT_LIST_SUCCESS;

  constructor(public payload: Department[]) {
  }
}

export class LoadDepartmentListError implements Action {
  readonly type = LOAD_DEPARTMENT_LIST_ERROR;

  constructor(public payload: string) {
  }
}

export type Mylib2Actions = Mylib2 | LoadMylib2 | Mylib2Loaded | LoadDepartmentList
| LoadDepartmentListError
| LoadDepartmentListSuccess;
