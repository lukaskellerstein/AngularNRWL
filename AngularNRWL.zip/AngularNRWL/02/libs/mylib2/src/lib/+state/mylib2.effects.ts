import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import {
  Mylib2Actions,
  Mylib2ActionTypes,
  LoadMylib2,
  Mylib2Loaded,
  LoadDepartmentList,
  LOAD_DEPARTMENT_LIST,
  LoadDepartmentListSuccess,
  LoadDepartmentListError
} from './mylib2.actions';
import { Mylib2State } from './mylib2.reducer';
import { DataPersistence } from '@nrwl/nx';
import { DepartmentService } from '../services/department.service';
import { switchMap, map, catchError } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';

@Injectable()
export class Mylib2Effects {
  @Effect() effect$ = this.actions$.ofType(Mylib2ActionTypes.Mylib2Action);

  @Effect()
  loadMylib2$ = this.dataPersistence.fetch(Mylib2ActionTypes.LoadMylib2, {
    run: (action: LoadMylib2, state: Mylib2State) => {
      return new Mylib2Loaded(state);
    },

    onError: (action: LoadMylib2, error) => {
      console.error('Error', error);
    }
  });

  constructor(
    private actions$: Actions,
    private dataPersistence: DataPersistence<Mylib2State>,
    private departmentService: DepartmentService
  ) {}



  /* Department list page*/
  @Effect()
  loadDepartmentList = this.actions$.pipe(
      ofType<LoadDepartmentList>(LOAD_DEPARTMENT_LIST),
      switchMap((action: LoadDepartmentList) => {
          return this.departmentService.getAllDepartments()
              .pipe(
                  map(department => new LoadDepartmentListSuccess(department)),
                  catchError((error: Error) => of(new LoadDepartmentListError(error.message)))
              );
      }));
}
