# Notes

NRWL + NgRX + Modules


# Install necessary libraries

NPM

`npm install -g @angular/cli`
`npm install -g @nrwl/schematics`
`npm install -g @ngrx/schematics`

or better approach is use a YARN

`yarn global add @angular/cli`
`yarn global add @nrwl/schematics`
`yarn global add @ngrx/schematics`


# Generate Solution

Create solution

`ng new TestSolution --collection=@nrwl/schematics`

## Create Application

Admin application
`ng g app myapp-admin --style=scss`

add Admin state
`ng generate ngrx app --module=apps/myapp-admin/src/app/app.module.ts  --root`


Web application
`ng g app myapp-web --style=scss`

add Web state
`ng generate ngrx app --module=apps/myapp-web/src/app/app.module.ts  --root`



## Create Common library

Common library will constist of LoginPage, ErrorPage, NotFoundPage ... etc.

`ng g lib common`

Add State
`ng generate ngrx common --module=libs/common/src/lib/common.module.ts`


## Create Widgets library

Widgets library is SHARED library for each feature module.

`ng g lib widgets`


## Create Feature libs / Feature modules

Business related modules / libs. For each feature module create this folder structure.

1. +State
- NgRx Store

2. Components
- Dumb Components - use @Input and @Output, doesn't know anything about services and state.

3. Containers
- Smart Components - wrapper for Dumb components, know everything about services and state.

4. Directives
- Angular custom directives

5. Pipes
- Angular custom pipes

6. Services
- Angular custom services

7. Entities
- Custom classes / types / entities


### Cafe Management

`ng g lib cafeManagement`

Add State
`ng generate ngrx cafe-management --module=libs/cafe-management/src/lib/cafe-management.module.ts`

Add some components
`ng g component dashboard`
`ng g component list`
`ng g component detail`

### Products Management

`ng g lib productsManagement`

Add State
`ng generate ngrx products-management --module=libs/products-management/src/lib/products-management.module.ts`

Add some components
`ng g component dashboard`
`ng g component list`
`ng g component detail`

### Trainings Management

`ng g lib trainingsManagement`

Add State
`ng generate ngrx trainings-management --module=libs/trainings-management/src/lib/trainings-management.module.ts`

Add some components
`ng g component dashboard`
`ng g component list`
`ng g component detail`




# RUN 

you can run every app independently

Web project
`ng serve --project=myapp-web`

Admin project
`ng serve --project=myapp-admin`