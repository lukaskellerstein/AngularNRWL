import { Component } from '@angular/core';
import { User } from 'libs/common/src/lib/entities/user';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { CommonState } from 'libs/common/src/lib/+state/stores/common.state';
import { AppState } from 'apps/myapp-web/src/app/+state/app.reducer';

@Component({
  selector: 'TestSolution-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'app';

  // actualUser$ = this.commonStore.select(state => state.identityState.actual_user);

  //actualUser$ = this.store.select('common');

  actualUser: User;

  constructor(
    private router: Router,
    private commonStore: Store<CommonState>,
    private store: Store<AppState>
  ) {
    // this.actualUser$.subscribe((value) => {
    //   if (value === null) {
    //     this.router.navigate(["/login"]);
    //   } else {
    //     this.router.navigate(["/"]);
    //   }
    // })
  }

  ngOnInit(): void {
    this.store.select<any>('common').subscribe((commonState: CommonState) => {
      this.actualUser = commonState.identityState.actual_user;

      if (this.actualUser === null) {
        this.router.navigate(['/login']);
      } else {
        this.router.navigate(['/']);
      }
    });
  }
}
