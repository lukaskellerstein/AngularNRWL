import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomePageComponent } from 'libs/common/src/lib/components/home-page/home-page.component';
import { LoginPageComponent } from 'libs/common/src/lib/containers/login-page/login-page.component';
import { ErrorPageComponent } from 'libs/common/src/lib/components/error-page/error-page.component';
import { NotFoundPageComponent } from 'libs/common/src/lib/components/not-found-page/not-found-page.component';

const routes: Routes = [
  { path: '', component: HomePageComponent },
  { path: 'login', component: LoginPageComponent },
  { path: 'error', component: ErrorPageComponent },
  { path: 'notFound', component: NotFoundPageComponent },
  {
    path: 'cafe',
    loadChildren:
      'libs/cafe-management/src/lib/cafe-management.module#CafeManagementModule'
  },
  {
    path: 'product',
    loadChildren:
      'libs/products-management/src/lib/products-management.module#ProductsManagementModule'
  },
  {
    path: 'trainings',
    loadChildren:
      'libs/trainings-management/src/lib/trainings-management.module#TrainingsManagementModule'
  },
  {
    path: '**',
    component: NotFoundPageComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
