import { TrainingsManagementLoaded } from './trainings-management.actions';
import {
  trainingsManagementReducer,
  initialState
} from './trainings-management.reducer';

describe('trainingsManagementReducer', () => {
  it('should work', () => {
    const action: TrainingsManagementLoaded = new TrainingsManagementLoaded({});
    const actual = trainingsManagementReducer(initialState, action);
    expect(actual).toEqual({});
  });
});
