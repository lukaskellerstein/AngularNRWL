import { Action } from '@ngrx/store';
import {
  TrainingsManagementActions,
  TrainingsManagementActionTypes
} from './trainings-management.actions';

/**
 * Interface for the 'TrainingsManagement' data used in
 *  - TrainingsManagementState, and
 *  - trainingsManagementReducer
 */
export interface TrainingsManagementData {}

/**
 * Interface to the part of the Store containing TrainingsManagementState
 * and other information related to TrainingsManagementData.
 */
export interface TrainingsManagementState {
  readonly trainingsManagement: TrainingsManagementData;
}

export const initialState: TrainingsManagementData = {};

export function trainingsManagementReducer(
  state = initialState,
  action: TrainingsManagementActions
): TrainingsManagementData {
  switch (action.type) {
    case TrainingsManagementActionTypes.TrainingsManagementAction:
      return state;

    case TrainingsManagementActionTypes.TrainingsManagementLoaded: {
      return { ...state, ...action.payload };
    }

    default:
      return state;
  }
}
