import { Injectable } from '@angular/core';
import { Actions, Effect } from '@ngrx/effects';
import {
  TrainingsManagementActions,
  TrainingsManagementActionTypes,
  LoadTrainingsManagement,
  TrainingsManagementLoaded
} from './trainings-management.actions';
import { TrainingsManagementState } from './trainings-management.reducer';
import { DataPersistence } from '@nrwl/nx';

@Injectable()
export class TrainingsManagementEffects {
  @Effect()
  effect$ = this.actions$.ofType(
    TrainingsManagementActionTypes.TrainingsManagementAction
  );

  @Effect()
  loadTrainingsManagement$ = this.dataPersistence.fetch(
    TrainingsManagementActionTypes.LoadTrainingsManagement,
    {
      run: (
        action: LoadTrainingsManagement,
        state: TrainingsManagementState
      ) => {
        return new TrainingsManagementLoaded(state);
      },

      onError: (action: LoadTrainingsManagement, error) => {
        console.error('Error', error);
      }
    }
  );

  constructor(
    private actions$: Actions,
    private dataPersistence: DataPersistence<TrainingsManagementState>
  ) {}
}
