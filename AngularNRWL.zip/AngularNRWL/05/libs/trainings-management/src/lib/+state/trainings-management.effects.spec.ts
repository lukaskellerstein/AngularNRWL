import { TestBed } from '@angular/core/testing';
import { StoreModule } from '@ngrx/store';
import { provideMockActions } from '@ngrx/effects/testing';
import { DataPersistence } from '@nrwl/nx';
import { hot } from '@nrwl/nx/testing';

import { TrainingsManagementEffects } from './trainings-management.effects';
import {
  LoadTrainingsManagement,
  TrainingsManagementLoaded
} from './trainings-management.actions';

import { Observable } from 'rxjs';

describe('TrainingsManagementEffects', () => {
  let actions$: Observable<any>;
  let effects$: TrainingsManagementEffects;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [StoreModule.forRoot({})],
      providers: [
        TrainingsManagementEffects,
        DataPersistence,
        provideMockActions(() => actions$)
      ]
    });

    effects$ = TestBed.get(TrainingsManagementEffects);
  });

  describe('someEffect', () => {
    it('should work', () => {
      actions$ = hot('-a-|', { a: new LoadTrainingsManagement({}) });
      expect(effects$.loadTrainingsManagement$).toBeObservable(
        hot('-a-|', { a: new TrainingsManagementLoaded({}) })
      );
    });
  });
});
