import { Action } from '@ngrx/store';

export enum TrainingsManagementActionTypes {
  TrainingsManagementAction = '[TrainingsManagement] Action',
  LoadTrainingsManagement = '[TrainingsManagement] Load Data',
  TrainingsManagementLoaded = '[TrainingsManagement] Data Loaded'
}

export class TrainingsManagement implements Action {
  readonly type = TrainingsManagementActionTypes.TrainingsManagementAction;
}
export class LoadTrainingsManagement implements Action {
  readonly type = TrainingsManagementActionTypes.LoadTrainingsManagement;
  constructor(public payload: any) {}
}

export class TrainingsManagementLoaded implements Action {
  readonly type = TrainingsManagementActionTypes.TrainingsManagementLoaded;
  constructor(public payload: any) {}
}

export type TrainingsManagementActions =
  | TrainingsManagement
  | LoadTrainingsManagement
  | TrainingsManagementLoaded;
