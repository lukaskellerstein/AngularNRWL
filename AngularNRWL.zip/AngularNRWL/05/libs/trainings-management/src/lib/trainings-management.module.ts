import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import {
  trainingsManagementReducer,
  initialState as trainingsManagementInitialState
} from './+state/trainings-management.reducer';
import { TrainingsManagementEffects } from './+state/trainings-management.effects';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ListComponent } from './components/list/list.component';
import { DetailComponent } from './components/detail/detail.component';
import { WidgetsModule } from '@TestSolution/widgets';
import { TrainingsManagementRoutingModule } from 'libs/trainings-management/src/lib/trainings-management-routing.module';
@NgModule({
  imports: [
    CommonModule,
    WidgetsModule,
    TrainingsManagementRoutingModule,
    StoreModule.forFeature('trainingsManagement', trainingsManagementReducer, {
      initialState: trainingsManagementInitialState
    }),
    EffectsModule.forFeature([TrainingsManagementEffects])
  ],
  providers: [TrainingsManagementEffects],
  declarations: [DashboardComponent, ListComponent, DetailComponent]
})
export class TrainingsManagementModule {}
