import { async, TestBed } from '@angular/core/testing';
import { TrainingsManagementModule } from './trainings-management.module';

describe('TrainingsManagementModule', () => {
  beforeEach(
    async(() => {
      TestBed.configureTestingModule({
        imports: [TrainingsManagementModule]
      }).compileComponents();
    })
  );

  it('should create', () => {
    expect(TrainingsManagementModule).toBeDefined();
  });
});
