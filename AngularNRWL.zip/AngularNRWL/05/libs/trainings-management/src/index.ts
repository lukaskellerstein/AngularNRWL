export * from './lib/trainings-management.module';
