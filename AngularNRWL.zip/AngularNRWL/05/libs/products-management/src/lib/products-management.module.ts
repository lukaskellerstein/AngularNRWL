import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import {
  productsManagementReducer,
  initialState as productsManagementInitialState
} from './+state/products-management.reducer';
import { ProductsManagementEffects } from './+state/products-management.effects';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ListComponent } from './components/list/list.component';
import { DetailComponent } from './components/detail/detail.component';
import { WidgetsModule } from '@TestSolution/widgets';
import { ProductManagementRoutingModule } from 'libs/products-management/src/lib/product-management-routing.module';
@NgModule({
  imports: [
    CommonModule,
    WidgetsModule,
    ProductManagementRoutingModule,
    StoreModule.forFeature('productsManagement', productsManagementReducer, {
      initialState: productsManagementInitialState
    }),
    EffectsModule.forFeature([ProductsManagementEffects])
  ],
  providers: [ProductsManagementEffects],
  declarations: [DashboardComponent, ListComponent, DetailComponent]
})
export class ProductsManagementModule {}
