import { async, TestBed } from '@angular/core/testing';
import { ProductsManagementModule } from './products-management.module';

describe('ProductsManagementModule', () => {
  beforeEach(
    async(() => {
      TestBed.configureTestingModule({
        imports: [ProductsManagementModule]
      }).compileComponents();
    })
  );

  it('should create', () => {
    expect(ProductsManagementModule).toBeDefined();
  });
});
