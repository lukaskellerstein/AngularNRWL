import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from 'libs/products-management/src/lib/components/dashboard/dashboard.component';
import { ListComponent } from 'libs/products-management/src/lib/components/list/list.component';
import { DetailComponent } from 'libs/products-management/src/lib/components/detail/detail.component';

const routes: Routes = [
  {
    path: '',
    children: [
      { path: '', component: DashboardComponent },
      { path: 'list', component: ListComponent },
      { path: 'detail', component: DetailComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProductManagementRoutingModule {}
