import { ProductsManagementLoaded } from './products-management.actions';
import {
  productsManagementReducer,
  initialState
} from './products-management.reducer';

describe('productsManagementReducer', () => {
  it('should work', () => {
    const action: ProductsManagementLoaded = new ProductsManagementLoaded({});
    const actual = productsManagementReducer(initialState, action);
    expect(actual).toEqual({});
  });
});
