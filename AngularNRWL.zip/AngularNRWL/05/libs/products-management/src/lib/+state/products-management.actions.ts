import { Action } from '@ngrx/store';

export enum ProductsManagementActionTypes {
  ProductsManagementAction = '[ProductsManagement] Action',
  LoadProductsManagement = '[ProductsManagement] Load Data',
  ProductsManagementLoaded = '[ProductsManagement] Data Loaded'
}

export class ProductsManagement implements Action {
  readonly type = ProductsManagementActionTypes.ProductsManagementAction;
}
export class LoadProductsManagement implements Action {
  readonly type = ProductsManagementActionTypes.LoadProductsManagement;
  constructor(public payload: any) {}
}

export class ProductsManagementLoaded implements Action {
  readonly type = ProductsManagementActionTypes.ProductsManagementLoaded;
  constructor(public payload: any) {}
}

export type ProductsManagementActions =
  | ProductsManagement
  | LoadProductsManagement
  | ProductsManagementLoaded;
