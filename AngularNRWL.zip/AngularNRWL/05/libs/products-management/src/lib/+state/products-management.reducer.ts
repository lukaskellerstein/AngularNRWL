import { Action } from '@ngrx/store';
import {
  ProductsManagementActions,
  ProductsManagementActionTypes
} from './products-management.actions';

/**
 * Interface for the 'ProductsManagement' data used in
 *  - ProductsManagementState, and
 *  - productsManagementReducer
 */
export interface ProductsManagementData {}

/**
 * Interface to the part of the Store containing ProductsManagementState
 * and other information related to ProductsManagementData.
 */
export interface ProductsManagementState {
  readonly productsManagement: ProductsManagementData;
}

export const initialState: ProductsManagementData = {};

export function productsManagementReducer(
  state = initialState,
  action: ProductsManagementActions
): ProductsManagementData {
  switch (action.type) {
    case ProductsManagementActionTypes.ProductsManagementAction:
      return state;

    case ProductsManagementActionTypes.ProductsManagementLoaded: {
      return { ...state, ...action.payload };
    }

    default:
      return state;
  }
}
