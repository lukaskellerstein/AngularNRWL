import { Injectable } from '@angular/core';
import { Actions, Effect } from '@ngrx/effects';
import {
  ProductsManagementActions,
  ProductsManagementActionTypes,
  LoadProductsManagement,
  ProductsManagementLoaded
} from './products-management.actions';
import { ProductsManagementState } from './products-management.reducer';
import { DataPersistence } from '@nrwl/nx';

@Injectable()
export class ProductsManagementEffects {
  @Effect()
  effect$ = this.actions$.ofType(
    ProductsManagementActionTypes.ProductsManagementAction
  );

  @Effect()
  loadProductsManagement$ = this.dataPersistence.fetch(
    ProductsManagementActionTypes.LoadProductsManagement,
    {
      run: (action: LoadProductsManagement, state: ProductsManagementState) => {
        return new ProductsManagementLoaded(state);
      },

      onError: (action: LoadProductsManagement, error) => {
        console.error('Error', error);
      }
    }
  );

  constructor(
    private actions$: Actions,
    private dataPersistence: DataPersistence<ProductsManagementState>
  ) {}
}
