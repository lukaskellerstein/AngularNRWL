import { TestBed } from '@angular/core/testing';
import { StoreModule } from '@ngrx/store';
import { provideMockActions } from '@ngrx/effects/testing';
import { DataPersistence } from '@nrwl/nx';
import { hot } from '@nrwl/nx/testing';

import { ProductsManagementEffects } from './products-management.effects';
import {
  LoadProductsManagement,
  ProductsManagementLoaded
} from './products-management.actions';

import { Observable } from 'rxjs';

describe('ProductsManagementEffects', () => {
  let actions$: Observable<any>;
  let effects$: ProductsManagementEffects;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [StoreModule.forRoot({})],
      providers: [
        ProductsManagementEffects,
        DataPersistence,
        provideMockActions(() => actions$)
      ]
    });

    effects$ = TestBed.get(ProductsManagementEffects);
  });

  describe('someEffect', () => {
    it('should work', () => {
      actions$ = hot('-a-|', { a: new LoadProductsManagement({}) });
      expect(effects$.loadProductsManagement$).toBeObservable(
        hot('-a-|', { a: new ProductsManagementLoaded({}) })
      );
    });
  });
});
