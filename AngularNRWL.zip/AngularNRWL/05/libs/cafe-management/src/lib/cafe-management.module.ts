import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import {
  cafeManagementReducer,
  initialState as cafeManagementInitialState
} from './+state/cafe-management.reducer';
import { CafeManagementEffects } from './+state/cafe-management.effects';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ListComponent } from './components/list/list.component';
import { DetailComponent } from './components/detail/detail.component';
import { WidgetsModule } from '@TestSolution/widgets';
import { CafeManagementRoutingModule } from 'libs/cafe-management/src/lib/cafe-management-routing.module';

@NgModule({
  imports: [
    CommonModule,
    WidgetsModule,
    CafeManagementRoutingModule,
    StoreModule.forFeature('cafeManagement', cafeManagementReducer, {
      initialState: cafeManagementInitialState
    }),
    EffectsModule.forFeature([CafeManagementEffects])
  ],
  providers: [CafeManagementEffects],
  declarations: [DashboardComponent, ListComponent, DetailComponent]
})
export class CafeManagementModule {}
