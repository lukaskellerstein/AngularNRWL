import { Injectable } from '@angular/core';
import { Actions, Effect } from '@ngrx/effects';
import {
  CafeManagementActions,
  CafeManagementActionTypes,
  LoadCafeManagement,
  CafeManagementLoaded
} from './cafe-management.actions';
import { CafeManagementState } from './cafe-management.reducer';
import { DataPersistence } from '@nrwl/nx';

@Injectable()
export class CafeManagementEffects {
  @Effect()
  effect$ = this.actions$.ofType(
    CafeManagementActionTypes.CafeManagementAction
  );

  @Effect()
  loadCafeManagement$ = this.dataPersistence.fetch(
    CafeManagementActionTypes.LoadCafeManagement,
    {
      run: (action: LoadCafeManagement, state: CafeManagementState) => {
        return new CafeManagementLoaded(state);
      },

      onError: (action: LoadCafeManagement, error) => {
        console.error('Error', error);
      }
    }
  );

  constructor(
    private actions$: Actions,
    private dataPersistence: DataPersistence<CafeManagementState>
  ) {}
}
