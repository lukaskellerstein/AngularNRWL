import { Action } from '@ngrx/store';

export enum CafeManagementActionTypes {
  CafeManagementAction = '[CafeManagement] Action',
  LoadCafeManagement = '[CafeManagement] Load Data',
  CafeManagementLoaded = '[CafeManagement] Data Loaded'
}

export class CafeManagement implements Action {
  readonly type = CafeManagementActionTypes.CafeManagementAction;
}
export class LoadCafeManagement implements Action {
  readonly type = CafeManagementActionTypes.LoadCafeManagement;
  constructor(public payload: any) {}
}

export class CafeManagementLoaded implements Action {
  readonly type = CafeManagementActionTypes.CafeManagementLoaded;
  constructor(public payload: any) {}
}

export type CafeManagementActions =
  | CafeManagement
  | LoadCafeManagement
  | CafeManagementLoaded;
