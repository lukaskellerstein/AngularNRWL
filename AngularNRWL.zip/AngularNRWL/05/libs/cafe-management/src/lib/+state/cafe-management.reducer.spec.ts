import { CafeManagementLoaded } from './cafe-management.actions';
import { cafeManagementReducer, initialState } from './cafe-management.reducer';

describe('cafeManagementReducer', () => {
  it('should work', () => {
    const action: CafeManagementLoaded = new CafeManagementLoaded({});
    const actual = cafeManagementReducer(initialState, action);
    expect(actual).toEqual({});
  });
});
