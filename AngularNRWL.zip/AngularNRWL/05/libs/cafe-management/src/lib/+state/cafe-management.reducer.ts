import { Action } from '@ngrx/store';
import {
  CafeManagementActions,
  CafeManagementActionTypes
} from './cafe-management.actions';

/**
 * Interface for the 'CafeManagement' data used in
 *  - CafeManagementState, and
 *  - cafeManagementReducer
 */
export interface CafeManagementData {}

/**
 * Interface to the part of the Store containing CafeManagementState
 * and other information related to CafeManagementData.
 */
export interface CafeManagementState {
  readonly cafeManagement: CafeManagementData;
}

export const initialState: CafeManagementData = {};

export function cafeManagementReducer(
  state = initialState,
  action: CafeManagementActions
): CafeManagementData {
  switch (action.type) {
    case CafeManagementActionTypes.CafeManagementAction:
      return state;

    case CafeManagementActionTypes.CafeManagementLoaded: {
      return { ...state, ...action.payload };
    }

    default:
      return state;
  }
}
