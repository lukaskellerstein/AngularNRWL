import { TestBed } from '@angular/core/testing';
import { StoreModule } from '@ngrx/store';
import { provideMockActions } from '@ngrx/effects/testing';
import { DataPersistence } from '@nrwl/nx';
import { hot } from '@nrwl/nx/testing';

import { CafeManagementEffects } from './cafe-management.effects';
import {
  LoadCafeManagement,
  CafeManagementLoaded
} from './cafe-management.actions';

import { Observable } from 'rxjs';

describe('CafeManagementEffects', () => {
  let actions$: Observable<any>;
  let effects$: CafeManagementEffects;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [StoreModule.forRoot({})],
      providers: [
        CafeManagementEffects,
        DataPersistence,
        provideMockActions(() => actions$)
      ]
    });

    effects$ = TestBed.get(CafeManagementEffects);
  });

  describe('someEffect', () => {
    it('should work', () => {
      actions$ = hot('-a-|', { a: new LoadCafeManagement({}) });
      expect(effects$.loadCafeManagement$).toBeObservable(
        hot('-a-|', { a: new CafeManagementLoaded({}) })
      );
    });
  });
});
