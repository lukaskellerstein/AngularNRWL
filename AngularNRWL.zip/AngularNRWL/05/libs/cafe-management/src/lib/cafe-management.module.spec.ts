import { async, TestBed } from '@angular/core/testing';
import { CafeManagementModule } from './cafe-management.module';

describe('CafeManagementModule', () => {
  beforeEach(
    async(() => {
      TestBed.configureTestingModule({
        imports: [CafeManagementModule]
      }).compileComponents();
    })
  );

  it('should create', () => {
    expect(CafeManagementModule).toBeDefined();
  });
});
