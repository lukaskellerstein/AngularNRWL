import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

//ngRX
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

//CUSTOM ngRx
import { commonReducers } from 'libs/common/src/lib/+state/reducers/common.reducers';
import { IdentityEffects } from 'libs/common/src/lib/+state/effects/identity.effects';
import { initialCommonState } from './+state/stores/common.state';

//Components
import { LoginFormComponent } from './components/login-form/login-form.component';
import { ErrorPageComponent } from './components/error-page/error-page.component';
import { NotFoundPageComponent } from './components/not-found-page/not-found-page.component';
import { HomePageComponent } from './components/home-page/home-page.component';

//Containers
import { LoginPageComponent } from './containers/login-page/login-page.component';

//Services
import { IdentityService } from './services/identity.service';

//Other modules
import { WidgetsModule } from '@TestSolution/widgets';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    WidgetsModule,
    StoreModule.forFeature('common', commonReducers, {
      initialState: initialCommonState
    }),
    EffectsModule.forFeature([IdentityEffects])
  ],
  declarations: [
    LoginPageComponent,
    LoginFormComponent,
    ErrorPageComponent,
    NotFoundPageComponent,
    HomePageComponent
  ],
  exports: [
    LoginPageComponent,
    LoginFormComponent,
    ErrorPageComponent,
    NotFoundPageComponent,
    HomePageComponent
  ],
  providers: [IdentityService, IdentityEffects]
})
export class MyCommonModule {}
