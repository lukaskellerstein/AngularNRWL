import { AllIdentityActions } from './identity.actions';

export type AllCommonActions = AllIdentityActions;
