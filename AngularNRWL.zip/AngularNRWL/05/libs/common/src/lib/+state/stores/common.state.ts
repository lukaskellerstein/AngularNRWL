import {
  IdentityState,
  initialIdentityState
} from 'libs/common/src/lib/+state/stores/identity.state';

/** Global state */
export interface CommonState {
  identityState: IdentityState;
}

export const initialCommonState: CommonState = {
  identityState: initialIdentityState
};
