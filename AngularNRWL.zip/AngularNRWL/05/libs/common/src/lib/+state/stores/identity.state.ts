import { User } from 'libs/common/src/lib/entities/user';

/** Substates */
export interface IdentityState {
  actual_user: User;
}

export const initialIdentityState: IdentityState = {
  actual_user: null
};
