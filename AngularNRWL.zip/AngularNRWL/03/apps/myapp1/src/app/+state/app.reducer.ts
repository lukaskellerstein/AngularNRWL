import { Action } from '@ngrx/store';
import {
  AppActions,
  AppActionTypes,
  LANGUAGE_CHANGE,
  LOAD_LANGUAGES_SUCCESS,
  LOAD_LANGUAGES_ERROR
} from './app.actions';

export interface LanguageState {
  lang: string;
  languages: any[];
  languageCodes: string[];
  loading: boolean;
  loaded: boolean;
  error: string;
}

export const initialLanguageState: LanguageState = {
  lang: 'cs-CZ',
  languages: [],
  languageCodes: [],
  loading: false,
  loaded: false,
  error: null
};

/**
 * Interface for the 'App' data used in
 *  - AppState, and
 *  - appReducer
 */
export interface AppData {
  languageState: LanguageState;
}

/**
 * Interface to the part of the Store containing AppState
 * and other information related to AppData.
 */
export interface AppState {
  readonly app: AppData;
}

export const initialState: AppData = {
  languageState: initialLanguageState
};

export function appReducer(state = initialState, action: AppActions): AppData {
  switch (action.type) {
    case AppActionTypes.AppAction:
      return state;

    case AppActionTypes.AppLoaded: {
      return { ...state, ...action.payload };
    }

    case LANGUAGE_CHANGE:
      return mapLanguageChange(state, action);

    case LOAD_LANGUAGES_SUCCESS:
      return mapLanguages(state, action);

    case LOAD_LANGUAGES_ERROR:
      return {
        ...state,
        languageState: {
          ...state.languageState,
          error: action.payload,
          loaded: false,
          loading: false
        }
      };

    default:
      return state;
  }
}


function mapLanguages(state: AppData, action: any): AppData {
  console.log(action.payload);

  return {
    ...state,
    languageState: {
      ...state.languageState,
      languages: action.payload,
      languageCodes: action.payload.map(l => l.code),
      loaded: true,
      loading: false
    }
  };
}


function mapLanguageChange(state: AppData, action: any): AppData {
  console.log(action.payload);

  return {
    ...state,
    languageState: {
      ...state.languageState,
      lang: state.languageState.lang
    }
  };
}
