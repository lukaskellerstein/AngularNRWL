import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import {
  mylib1Reducer,
  initialState as mylib1InitialState
} from './+state/mylib1.reducer';
import { Mylib1Effects } from './+state/mylib1.effects';
import { EmployeeService } from './services/employees.service';

import { Mylib2Module } from '@TestSolution2/mylib2';
import { InfoDashboardComponent } from './containers/info-dashboard/info-dashboard.component';
import { EmployeeListComponent } from './components/employee-list/employee-list.component';

@NgModule({
  imports: [
    CommonModule,
    StoreModule.forFeature('mylib1', mylib1Reducer, {
      initialState: mylib1InitialState
    }),
    EffectsModule.forFeature([Mylib1Effects]),
    Mylib2Module
  ],
  providers: [Mylib1Effects, EmployeeService],
  declarations: [InfoDashboardComponent, EmployeeListComponent],
  exports: [InfoDashboardComponent]
})
export class Mylib1Module {}
