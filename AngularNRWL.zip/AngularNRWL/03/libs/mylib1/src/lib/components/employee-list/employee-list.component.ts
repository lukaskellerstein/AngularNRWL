import { Component, OnInit, Input } from '@angular/core';
import { Employee } from '../../entities/employee.model';

@Component({
  selector: 'TestSolution2-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  @Input()
  items: Employee[] = [];

  constructor() { }

  ngOnInit() {
  }

}
