import { Component, OnInit } from '@angular/core';
import { Mylib1State } from '../../+state/mylib1.reducer';
import { Mylib2State } from '../../../../../mylib2/src/lib/+state/mylib2.reducer';
import { Department } from 'libs/mylib2/src/lib/entitites/department.model';
import { Employee } from 'libs/mylib1/src/lib/entities/employee.model';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { LoadEmployeesList } from '../../+state/mylib1.actions';
import { LoadDepartmentList } from '../../../../../mylib2/src/lib/+state/mylib2.actions';

@Component({
  selector: 'TestSolution2-info-dashboard',
  templateUrl: './info-dashboard.component.html',
  styleUrls: ['./info-dashboard.component.css']
})
export class InfoDashboardComponent implements OnInit {

  employees$: Observable<Employee[]>;
  departments$: Observable<Department[]>;

  constructor(private storeLib1: Store<Mylib1State>,
    private storeLib2: Store<Mylib2State>) {

      this.employees$ = this.storeLib1.select(
        state => state.mylib1.employeesList.employees
      );
    
      this.departments$ = this.storeLib2.select(
        state => state.mylib2.departmentList.departments
      );

    }

  
  

  ngOnInit() {
    this.storeLib1.dispatch(new LoadEmployeesList());
    this.storeLib2.dispatch(new LoadDepartmentList());
  }

}
