export interface Employee {
  name: string;
  description?: string;
  image?: string;
}
