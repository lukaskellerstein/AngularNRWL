# Notes

myapp1 = using NgRX and dispatch action from one libraries in the other one.

# Generate Solution

`npm install -g @angular/cli`
`npm install -g @nrwl/schematics`
`npm install -g @ngrx/schematics`

or better approach is use a YARN

`yarn global add @angular/cli`
`yarn global add @nrwl/schematics`
`yarn global add @ngrx/schematics`

Create solution

`ng new TestSolution2 --collection=@nrwl/schematics --style=scss`

## Create Application

`ng g app myapp1`

## Create library

`ng g lib mylib1`


## Add NgRX

Root state
`ng generate ngrx app --module=apps/myapp1/src/app/app.module.ts  --root`

Feature state
`ng generate ngrx mylib1 --module=libs/mylib1/src/lib/mylib1.module.ts`


# RUN 

you can run every app independently

`ng serve --project=myapp1`