We can also create the whole solution by 

Git submodules and Yarn Workspaces

Sample projects are showed in :
https://github.com/nrwl/nx-example-multirepo

consist of these two repos
- https://github.com/nrwl/nx-example-sharedlib
- https://github.com/nrwl/nx-example-workspace