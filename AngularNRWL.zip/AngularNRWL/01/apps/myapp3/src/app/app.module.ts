import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { NxModule } from '@nrwl/nx';

import { Mylib3Module } from '@TestSolution/mylib3';

@NgModule({
  declarations: [AppComponent],
  imports: [BrowserModule, NxModule.forRoot(), Mylib3Module],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
