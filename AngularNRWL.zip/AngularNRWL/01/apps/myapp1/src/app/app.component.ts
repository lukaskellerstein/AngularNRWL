import { Component } from '@angular/core';

import { MyClass1 } from '@TestSolution/mylib1';

@Component({
  selector: 'TestSolution-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'TestSolution';
  title2 = '';

  constructor() {
    let aaa = new MyClass1();
    this.title2 = aaa.getSomeRandomString();
  }
}
