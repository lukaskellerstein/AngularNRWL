import { Component } from '@angular/core';

@Component({
  selector: 'TestSolution-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'TestSolution';

  logClick(e) {
    console.log('CLICK');
  }
}
