import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatButtonModule, MatCheckboxModule} from '@angular/material';
import { MyMatButtonComponent } from './components/my-mat-button/my-mat-button.component';

@NgModule({
  imports: [ CommonModule, BrowserAnimationsModule, MatButtonModule, MatCheckboxModule ],
  declarations: [ MyMatButtonComponent ],
  exports: [ MyMatButtonComponent ]
})
export class Mylib3Module {}
