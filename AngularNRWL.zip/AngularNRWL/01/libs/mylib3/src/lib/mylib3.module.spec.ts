import { async, TestBed } from '@angular/core/testing';
import { Mylib3Module } from './mylib3.module';

describe('Mylib3Module', () => {
  beforeEach(
    async(() => {
      TestBed.configureTestingModule({
        imports: [Mylib3Module]
      }).compileComponents();
    })
  );

  it('should create', () => {
    expect(Mylib3Module).toBeDefined();
  });
});
