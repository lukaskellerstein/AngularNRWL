import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
//import { MyClass1 } from './myClass1';

@NgModule({
  imports: [CommonModule]
  //exports: [MyClass1]
})
export class Mylib1Module {}
