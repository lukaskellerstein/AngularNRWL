import { async, TestBed } from '@angular/core/testing';
import { Mylib2Module } from './mylib2.module';

describe('Mylib2Module', () => {
  beforeEach(
    async(() => {
      TestBed.configureTestingModule({
        imports: [Mylib2Module]
      }).compileComponents();
    })
  );

  it('should create', () => {
    expect(Mylib2Module).toBeDefined();
  });
});
