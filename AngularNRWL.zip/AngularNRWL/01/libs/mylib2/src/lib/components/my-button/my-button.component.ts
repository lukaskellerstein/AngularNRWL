import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'TestSolution-my-button',
  templateUrl: './my-button.component.html',
  styleUrls: ['./my-button.component.css']
})
export class MyButtonComponent implements OnInit {
  @Input() text: string = '';

  @Output() onClick = new EventEmitter();

  constructor() {}

  ngOnInit() {}

  onInternalClick(event) {
    this.onClick.emit(event);
  }
}
