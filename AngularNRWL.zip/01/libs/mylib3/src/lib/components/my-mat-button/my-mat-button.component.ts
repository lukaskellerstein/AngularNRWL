import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'TestSolution-my-mat-button',
  templateUrl: './my-mat-button.component.html',
  styleUrls: ['./my-mat-button.component.css']
})
export class MyMatButtonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
