# Notes

myapp1 = using mylib1 (it has only one class)
myapp2 = using mylib2 (it has custom component)
myapp3 = using mylib3 (it has custom material component)

# Generate Solution

`npm install -g @nrwl/schematics`
`npm install -g @ngrx/schematics`

Create solution

`ng new TestSolution --collection=@nrwl/schematics`

## Create Application

`ng g app myapp1`

## Create library

`ng g lib mylib1`


# RUN 

you can run every app independently

`ng serve --project=myapp1`