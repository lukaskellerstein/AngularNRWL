import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Employee } from '../entities/employee.model';
import { of } from 'rxjs/observable/of';

@Injectable()
export class EmployeeService {
  constructor(private http: HttpClient) {}

  getAllEmployees(): Observable<Employee[]> {
    let newItem1 = <Employee>{
      name: 'Lukas Kellerstein',
      description: 'Developer',
      image: 'none'
    };

    let newItem2 = <Employee>{
      name: 'Filip Jezek',
      description: 'Junior developer',
      image: 'none'
    };

    let newItem3 = <Employee>{
      name: 'Gaurav Shetty',
      description: 'Developer',
      image: 'none'
    };

    let result = new Array<Employee>();
    result.push(newItem1);
    result.push(newItem2);
    result.push(newItem3);

    return of(result);
  }
}
