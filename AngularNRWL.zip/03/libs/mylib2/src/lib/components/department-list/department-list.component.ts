import { Component, OnInit, Input } from '@angular/core';
import { Department } from '../../entitites/department.model';

@Component({
  selector: 'TestSolution2-department-list',
  templateUrl: './department-list.component.html',
  styleUrls: ['./department-list.component.css']
})
export class DepartmentListComponent implements OnInit {

  @Input()
  items: Department[];

  constructor() { }

  ngOnInit() {
  }

}
